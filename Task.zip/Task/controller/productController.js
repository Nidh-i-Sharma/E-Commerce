import productModal from "../modal/productModal.js";
import transactionModal from "../modal/transactionModal.js";
import walletModal from "../modal/walletModal.js";
import mongoose from 'mongoose';


export  async function addProduct(req,res){
    try {
        const { amount, description } = req.body;
    const product = new productModal(
        {
            amount: amount, 
            description: description, 
        });
    await product.save();
    res.json({ data:product});
    } catch(error){
        console.log(error);
        return res.status(500).json({ message: "Internal Server Error", error: JSON.stringify(error), success: false })
    }
}
export  async function productListing(req,res){
    try {
    const productList = await productModal.find();
    res.json({data: productList });
    } catch(error){
        console.log(error);
        return res.status(500).json({ message: "Internal Server Error", error: JSON.stringify(error), success: false })
    }
}
export  async function purchaseProduct(req,res){
  const walletId = req.params.walletId;
  const productId = req.body.productId;
  try {
    const wallet = await walletModal.findOne({ _id : new mongoose.Types.ObjectId(walletId) });
    if (!wallet) {
      return res.status(404).json({ error: 'Wallet not found' });
    }
    const product = await productModal.findOne({ _id : new mongoose.Types.ObjectId(productId) });
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    if (wallet.balance < product.amount) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }
    const transaction = new transactionModal({
      walletId,
      description: `Purchased ${product.description}`,
      amount: product.amount,
      type: 'debit',
      productId,
    });
    const updatedBalance = wallet.balance - product.amount;
    await transaction.save();
    await walletModal.findByIdAndUpdate({ walletId }, { balance: updatedBalance });
    const result = {
      balance: updatedBalance,
      transactionId: transaction._id,
      description: transaction.description,
      type: transaction.type,
      productId: transaction.productId,
      createdAt: transaction.createdAt,
    };
    return res.json(result);
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal Server Error", error: JSON.stringify(error), success: false })
  }
}