import transactionModal from '../modal/transactionModal.js';
import walletModal from '../modal/walletModal.js';
import mongoose from 'mongoose';

export async function createWallet(req, res) {
    try {
        const { balance, name } = req.body;
        const wallet = new walletModal({ balance, name, createdAt: new Date() });
        const savedWallet = await wallet.save();
        const transaction = new transactionModal({ walletId: savedWallet._id, amount: balance, type: 'credit', description: 'Initial balance', createdAt: new Date() });
        await transaction.save();
        res.json({ walletId: savedWallet._id, balance: savedWallet.balance, name: savedWallet.name, transactionId: transaction._id, date: transaction.createdAt });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Internal Server Error", error: JSON.stringify(error), success: false })
    }
}
export async function createWalletasync(req, res) {
    try {
        const { walletId } = req.params;
        const wallet = await walletModal.findById(walletId);
        if (!wallet) return res.status(404).json({ message: 'Wallet not found' });
        res.json({ walletId: wallet._id, balance: wallet.balance, name: wallet.name, createdAt: wallet.createdAt });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Internal Server Error", error: JSON.stringify(error), success: false })
    }
};
export async function updateBalance(req, res) {
    try {
        const { amount, description } = req.body;
        const transaction = new transactionModal({
            walletId: req.params.walletId,
            amount,
            description,
            type: 'credit'
        });
        const wallet = await walletModal.findByIdAndUpdate(req.params.walletId,
            { $inc: { balance: amount } },
            { new: true });
        await transaction.save();
        res.json({
            balance: wallet.balance,
            transactionId: transaction._id,
            description: transaction.description,
            type: transaction.type,
            createdAt: transaction.createdAt
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Internal Server Error", error: JSON.stringify(error), success: false })
    }
};
export async function balanceDetails(req, res) {
    const walletId = req.params.walletId;
    const skip = parseInt(req.query.skip) || 0;
    const limit = parseInt(req.query.limit) || 10;
    try {
        const wallet = await walletModal.findOne({ _id: new mongoose.Types.ObjectId(walletId) });
        if (!wallet) {
            return res.status(404).json({ error: 'Wallet not found' });
        }
        const transactions = await transactionModal.find({ walletId })
            .sort({ createdAt: 'desc' })
            .skip(skip)
            .limit(limit);
        return res.json(transactions);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Internal Server Error", error: JSON.stringify(error), success: false })
    }
}