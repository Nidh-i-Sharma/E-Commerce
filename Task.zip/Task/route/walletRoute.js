import { Router } from 'express';
import { productListing ,purchaseProduct,addProduct} from '../controller/productController.js';
import { createWallet ,createWalletasync,updateBalance,balanceDetails} from '../controller/walletController.js';
const router = Router();

router.post('/wallet',createWallet)
  
router.get('/wallet/:walletId', createWalletasync)
  
router.post('/wallet/:walletId/transaction',updateBalance)

router.get('/product',productListing)
router.post('/product',addProduct)

router.post('/{walletId}/purchase',purchaseProduct)

router.get('/:walletId/transaction',balanceDetails)
export default router;