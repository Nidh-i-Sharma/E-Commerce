import mongoose, { Schema } from 'mongoose'
const walletSchema = new mongoose.Schema({
    balance: Number,
    name: String,
    createdAt: Date,
  });

var walletModal = mongoose.model('wallet', walletSchema)
export default walletModal;