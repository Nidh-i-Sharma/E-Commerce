import mongoose, { Schema } from 'mongoose'

const productSchema = new mongoose.Schema({
    amount: Number,
    description: String,
});

var productModal = mongoose.model('product', productSchema)
export default productModal;