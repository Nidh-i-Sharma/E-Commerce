import mongoose, { Schema } from 'mongoose'
const transactionSchema = new mongoose.Schema({
    walletId: mongoose.Schema.Types.ObjectId,
    amount: Number,
    description: String,
    type: String,
    productId: mongoose.Schema.Types.ObjectId,
    createdAt: Date,
  });
  
var transactionModal = mongoose.model('transaction', transactionSchema)
export default transactionModal;