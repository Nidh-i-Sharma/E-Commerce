import express, { urlencoded } from 'express';
import { connect } from 'mongoose';
import { createWallet } from './controller/walletController.js';
import walletRoute from './route/walletRoute.js';

const app = express();

const PORT = 4200
const MONGOURI = 'mongodb://localhost:27017/eCommerce' // put these var into  .env files
connect(MONGOURI, { useNewUrlParser: true });
app.use(express.json());
app.use(express.urlencoded({extended:false}))
app.use('/wallet',walletRoute)

app.listen(PORT , () => {
    console.log(`server started on ${PORT}`)
})